//
//  RLottie.h
//  RLottie
//
//  Created by Peter on 6/25/19.
//  Copyright © 2019 Telegram LLP. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RLottie.
FOUNDATION_EXPORT double RLottieVersionNumber;

//! Project version string for RLottie.
FOUNDATION_EXPORT const unsigned char RLottieVersionString[];

#import <RLottie/LottieInstance.h>


